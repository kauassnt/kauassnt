<div align="center">

<img src="./assets/hero.svg" width="100%" alt="Kauã — Full-Stack Developer"/>

</div>

<br/>

## Sobre mim

Sou Kauã, desenvolvedor Full-Stack focado em transformar ideias em produtos digitais.

Trabalho principalmente com websites, sistemas web, SaaS, e-commerce, automações e integrações com inteligência artificial.

Gosto de projetos que combinam engenharia e design: sistemas bem estruturados por dentro e simples de usar por fora.

<img src="./assets/divider.svg" width="100%" alt=""/>

## O que eu construo

**Websites**  
Landing pages, sites institucionais e experiências digitais.

**SaaS**  
Plataformas completas com autenticação, APIs, banco de dados e dashboards.

**Sistemas Web**  
Painéis administrativos, ferramentas internas e sistemas personalizados.

**E-commerce**  
Lojas, catálogos e operações digitais.

**AI & Automation**  
Inteligência artificial, APIs, WhatsApp, webhooks, workflows e integrações.

<img src="./assets/divider.svg" width="100%" alt=""/>

## Stack

**Frontend**  
Next.js · React · TypeScript · JavaScript · Tailwind CSS · HTML · CSS

**Backend**  
Node.js · NestJS · Express · Prisma

**Data**  
PostgreSQL · MongoDB · Redis · Supabase

**Infrastructure & Tools**  
Docker · Vercel · AWS · Cloudflare · Nginx · Linux · Git · GitHub · VS Code · Postman

<img src="./assets/divider.svg" width="100%" alt=""/>

## Projetos

### Mottu SAJ

Plataforma de automação e gerenciamento através do WhatsApp.

`Next.js` `React` `TypeScript` `Prisma` `PostgreSQL`

### ProjectFlow AI

Canvas visual para organizar arquiteturas, sistemas e fluxos de projetos.

`React` `React Flow` `Framer Motion` `NestJS`

### DevVision

Projeto voltado ao desenvolvimento de soluções digitais para empresas.

`Websites` `Landing Pages` `Sistemas` `E-commerce` `SaaS` `Automação`

<img src="./assets/divider.svg" width="100%" alt=""/>

## Como gosto de trabalhar

**Clareza**  
Interfaces que não precisam ser explicadas.

**Performance**  
Menos espera e mais fluidez.

**Escala**  
Arquitetura preparada para crescer.

**Detalhes**  
Pequenas decisões fazem diferença.

> Bons produtos não precisam parecer complicados.
>
> A tecnologia pode ser sofisticada por trás e extremamente simples para quem usa.

<img src="./assets/divider.svg" width="100%" alt=""/>

## Atualmente

Arquitetura de sistemas · Desenvolvimento de SaaS · Inteligência artificial · Automações · APIs e integrações · Performance · Escalabilidade · Experiência do usuário

<img src="./assets/divider.svg" width="100%" alt=""/>

## GitHub

<div align="center">

<img height="165" alt="GitHub stats" src="https://github-readme-stats.vercel.app/api?username=kauassnt&show_icons=true&hide_border=true&bg_color=00000000&title_color=A78BFA&text_color=A1A1AA&icon_color=A78BFA&hide_title=true&card_width=420"/>
<img height="165" alt="Top languages" src="https://github-readme-stats.vercel.app/api/top-langs/?username=kauassnt&layout=compact&hide_border=true&bg_color=00000000&title_color=A78BFA&text_color=A1A1AA&hide_title=true&card_width=300"/>

</div>

<img src="./assets/divider.svg" width="100%" alt=""/>

## Contato

[kauassnt@outlook.com](mailto:kauassnt@outlook.com) · [github.com/kauassnt](https://github.com/kauassnt)

<br/>

<div align="center">

<img src="./assets/footer.svg" width="100%" alt="Built with curiosity."/>

</div>
